package banking.bean;

public class Transaction {
	private int accountNo;
	private double initialBalance;
	private double currentBalance;

	public Transaction(int accountNo, double initialBalance, double currentBalance) {
		super();
		this.accountNo = accountNo;
		this.initialBalance = initialBalance;
		this.currentBalance = currentBalance;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public double getInitialBalance() {
		return initialBalance;
	}

	public void setInitialBalance(double initialBalance) {
		this.initialBalance = initialBalance;
	}

	public double getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(double currentBalance) {
		this.currentBalance = currentBalance;
	}

	@Override
	public String toString() {
		return "Transaction [accountNo=" + accountNo + ", initialBalance=" + initialBalance + ", currentBalance="
				+ currentBalance + "]";
	}

}
